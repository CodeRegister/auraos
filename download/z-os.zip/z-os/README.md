# Z-OS

A tiny operating-system-style desktop that lives entirely in your browser.
Window manager, terminal, file manager, editor — no build step, no
dependencies, no framework. Open one HTML file and you have a desktop.

## Features

- **Window manager (zwm)** — drag, resize, minimize, maximize, focus
  stacking, taskbar with live window list
- **Terminal** — a simulated shell over a virtual filesystem: `help`,
  `neofetch`, `ls`, `cd`, `pwd`, `cat`, `echo`, `mkdir`, `touch`, `rm`,
  `mv`, `open`, `ps`, `fps`, `date`, `whoami`, `clear`, `reboot`
- **Files** — folders and files with create / rename / delete, breadcrumb
  navigation, back/up, instant two-way sync with the terminal
- **Editor** — open and save text files, Ctrl+S, dirty-state marker
- **Settings** — wallpaper presets and accent colors, persisted to
  localStorage
- **60 FPS discipline** — pointer input is batched into
  `requestAnimationFrame`; windows move on compositor transforms
  (`translate3d`), so dragging never triggers layout; a live FPS meter
  sits in the tray so the claim is checkable, not decorative

## Run it

Open `index.html`. That's the whole install.

Prefer a server?

```sh
python3 -m http.server 8000
# http://localhost:8000
```

## Push to your GitHub

Create an empty repository named `z-os`, then:

```sh
git remote add origin https://github.com/YOU/z-os.git
git push -u origin main
```

## Project layout

```
index.html            the whole shell
css/zos.css           design system + app styles
js/kernel.js          event bus + virtual filesystem + persistence
js/wm.js              window manager (rAF-batched, compositor transforms)
js/apps/terminal.js   the shell
js/apps/files.js      folder management
js/apps/editor.js     text editor
js/apps/settings.js   wallpapers + accent
js/apps/about.js      live system panel
js/boot.js            boot sequence, desktop, start menu, clock, fps
```

## Where the commits come from

`/home/guest/Documents/roadmap.md` (in Files, or via the terminal) is the
standing list of next features — tab completion, snap zones, pipes, new
apps. Pick one, ship it, commit. Real work, real history.

## License

MIT
