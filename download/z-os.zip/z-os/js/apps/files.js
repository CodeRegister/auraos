/* ============================================================
   Z-OS Files — folder management over the virtual filesystem
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;

  const FOLDER_ICON = '<span class="fi-ico ico-folder"></span>';
  const FILE_ICON = '<span class="fi-ico ico-file"></span>';

  function app(body, win, opts) {
    body.classList.add('files-app');
    body.innerHTML =
      '<div class="files-toolbar">' +
      '<button class="ft-back" title="Back">&#8592;</button>' +
      '<button class="ft-up" title="Parent folder">&#8593;</button>' +
      '<nav class="ft-path"></nav>' +
      '<button class="ft-newdir">+ Folder</button>' +
      '<button class="ft-newfile">+ File</button>' +
      '<button class="ft-rename" disabled>Rename</button>' +
      '<button class="ft-delete" disabled>Delete</button>' +
      '</div>' +
      '<div class="files-grid"></div>';

    const $ = (sel) => body.querySelector(sel);
    const grid = $('.files-grid');
    const pathNav = $('.ft-path');
    const backBtn = $('.ft-back');
    const upBtn = $('.ft-up');
    const newDirBtn = $('.ft-newdir');
    const newFileBtn = $('.ft-newfile');
    const renBtn = $('.ft-rename');
    const delBtn = $('.ft-delete');

    const state = {
      cwd: (opts && opts.path) || ZOS.fs.HOME,
      sel: null,
      back: [],
    };

    function selPath() {
      return state.sel ? ZOS.fs.resolve(state.cwd, state.sel) : null;
    }
    function syncBtns() {
      renBtn.disabled = !state.sel;
      delBtn.disabled = !state.sel;
    }
    function refreshSelClasses() {
      const items = grid.querySelectorAll('.file-item');
      for (const it of items) it.classList.toggle('selected', it.dataset.name === state.sel);
    }
    function fail(err) {
      window.alert(err && err.message ? err.message : String(err));
    }

    function render() {
      /* breadcrumb */
      pathNav.textContent = '';
      const parts = state.cwd.split('/').filter(Boolean);
      const crumbs = [{ name: 'Z:', path: '/' }].concat(
        parts.map((p, i) => ({ name: p, path: '/' + parts.slice(0, i + 1).join('/') }))
      );
      crumbs.forEach((c, i) => {
        const s = document.createElement('span');
        s.className = 'crumb';
        s.textContent = c.name;
        s.addEventListener('click', () => nav(c.path));
        pathNav.appendChild(s);
        if (i < crumbs.length - 1) {
          const sep = document.createElement('span');
          sep.className = 'crumb-sep';
          sep.textContent = '\u203A';
          pathNav.appendChild(sep);
        }
      });

      /* grid */
      grid.textContent = '';
      let names;
      try { names = ZOS.fs.ls(state.cwd); }
      catch (err) {
        state.cwd = ZOS.fs.HOME;
        names = ZOS.fs.ls(state.cwd);
      }
      if (!names.length) {
        const empty = document.createElement('div');
        empty.className = 'files-empty';
        empty.textContent = 'empty folder';
        grid.appendChild(empty);
      }
      for (const name of names) {
        const full = ZOS.fs.resolve(state.cwd, name);
        const isDir = ZOS.fs.isDir(full);
        const item = document.createElement('button');
        item.className = 'file-item';
        item.dataset.name = name;
        item.innerHTML = isDir ? FOLDER_ICON : FILE_ICON;
        const label = document.createElement('span');
        label.className = 'fi-label';
        label.textContent = name;
        item.appendChild(label);
        item.addEventListener('click', () => {
          state.sel = name;
          refreshSelClasses();
          syncBtns();
        });
        item.addEventListener('dblclick', () => {
          if (isDir) nav(full);
          else ZOS.desktop.launch('editor', { path: full });
        });
        grid.appendChild(item);
      }

      upBtn.disabled = state.cwd === '/';
      backBtn.disabled = !state.back.length;
      syncBtns();
    }

    function nav(p, push) {
      if (push !== false && p !== state.cwd) state.back.push(state.cwd);
      state.cwd = p;
      state.sel = null;
      render();
    }

    backBtn.addEventListener('click', () => {
      const prev = state.back.pop();
      if (prev) {
        state.cwd = prev;
        state.sel = null;
        render();
      }
    });
    upBtn.addEventListener('click', () => {
      if (state.cwd !== '/') nav(ZOS.fs.parentOf(state.cwd));
    });
    newDirBtn.addEventListener('click', () => {
      const name = window.prompt('New folder name:');
      if (!name) return;
      try { ZOS.fs.mkdir(ZOS.fs.resolve(state.cwd, name)); }
      catch (err) { fail(err); }
    });
    newFileBtn.addEventListener('click', () => {
      const name = window.prompt('New file name:', 'untitled.txt');
      if (!name) return;
      try { ZOS.fs.writeFile(ZOS.fs.resolve(state.cwd, name), ''); }
      catch (err) { fail(err); }
    });
    renBtn.addEventListener('click', () => {
      if (!state.sel) return;
      const name = window.prompt('Rename "' + state.sel + '" to:', state.sel);
      if (!name || name === state.sel) return;
      try {
        ZOS.fs.mv(selPath(), ZOS.fs.resolve(state.cwd, name));
        state.sel = null;
      } catch (err) { fail(err); }
    });
    delBtn.addEventListener('click', () => {
      if (!state.sel) return;
      if (!window.confirm('Delete "' + state.sel + '"?')) return;
      try {
        ZOS.fs.rm(selPath(), true);
        state.sel = null;
      } catch (err) { fail(err); }
    });

    const off = ZOS.bus.on('fs:changed', render);
    win.onClose = off;

    render();
  }

  ZOS.registerApp({
    id: 'files',
    name: 'Files',
    icon: '\uD83D\uDDC1',
    desktop: true,
    width: 660,
    height: 430,
    launch(b, w, o) { app(b, w, o); },
  });
})();
