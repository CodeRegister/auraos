/* ============================================================
   Z-OS Editor — open/save text files from the VFS
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;

  function app(body, win, opts) {
    body.classList.add('editor-app');
    body.innerHTML =
      '<div class="ed-bar">' +
      '<span class="ed-path">untitled</span>' +
      '<span class="ed-spacer"></span>' +
      '<button class="ed-save">Save</button>' +
      '</div>' +
      '<textarea class="ed-area" spellcheck="false" placeholder="type something..."></textarea>';

    const $ = (sel) => body.querySelector(sel);
    const area = $('.ed-area');
    const pathEl = $('.ed-path');
    const saveBtn = $('.ed-save');

    let path = (opts && opts.path) || null;

    function setTitle(dirty) {
      const t = (path ? 'Editor \u2014 ' + path : 'Editor \u2014 untitled') + (dirty ? ' \u2022' : '');
      win.el.querySelector('.tb-title').textContent = t;
      win.title = t;
      if (win.taskEl) win.taskEl.textContent = t;
    }

    function save() {
      if (!path) {
        const p = window.prompt('Save as (path):', '~/untitled.txt');
        if (!p) return;
        path = ZOS.fs.resolve(ZOS.fs.HOME, p);
      }
      try {
        ZOS.fs.writeFile(path, area.value);
        pathEl.textContent = path;
        setTitle(false);
      } catch (err) {
        window.alert(err && err.message ? err.message : String(err));
      }
    }

    saveBtn.addEventListener('click', save);
    area.addEventListener('input', () => setTitle(true));
    area.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        save();
      }
    });

    if (path && ZOS.fs.exists(path)) {
      area.value = ZOS.fs.readFile(path);
      pathEl.textContent = path;
    }
    setTitle(false);
    setTimeout(() => area.focus(), 60);
  }

  ZOS.registerApp({
    id: 'editor',
    name: 'Editor',
    icon: '\u270E',
    width: 580,
    height: 430,
    launch(b, w, o) { app(b, w, o); },
  });
})();
