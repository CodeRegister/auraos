/* ============================================================
   Z-OS Settings — wallpapers + accent color, persisted
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;

  ZOS.WALLPAPERS = [
    {
      name: 'Nebula',
      css: 'radial-gradient(1100px 700px at 18% 8%, #312a5e 0%, rgba(49,42,94,0) 60%), ' +
           'radial-gradient(900px 600px at 85% 92%, #10394d 0%, rgba(16,57,77,0) 55%), ' +
           'linear-gradient(160deg, #0a0c12 0%, #121627 100%)',
    },
    {
      name: 'Ember',
      css: 'radial-gradient(1000px 600px at 80% 12%, #4d2436 0%, rgba(77,36,54,0) 60%), ' +
           'radial-gradient(900px 700px at 15% 85%, #233a4d 0%, rgba(35,58,77,0) 55%), ' +
           'linear-gradient(160deg, #0c0b10 0%, #16131d 100%)',
    },
    {
      name: 'Forest',
      css: 'radial-gradient(1000px 650px at 25% 15%, #1d3f33 0%, rgba(29,63,51,0) 60%), ' +
           'radial-gradient(900px 600px at 85% 80%, #243a52 0%, rgba(36,58,82,0) 55%), ' +
           'linear-gradient(160deg, #0a0e0c 0%, #101a18 100%)',
    },
    {
      name: 'Graphite',
      css: 'radial-gradient(1200px 800px at 50% 0%, #262a33 0%, rgba(38,42,51,0) 65%), ' +
           'linear-gradient(160deg, #0b0c10 0%, #13151b 100%)',
    },
  ];

  ZOS.ACCENTS = [
    { name: 'Violet', c: '#8b7cf7' },
    { name: 'Cyan',   c: '#39c5cf' },
    { name: 'Lime',   c: '#7fd15c' },
    { name: 'Amber',  c: '#e0a33c' },
  ];

  function app(body) {
    body.classList.add('settings-app');
    body.innerHTML =
      '<h3>Wallpaper</h3><div class="swatch-grid walls"></div>' +
      '<h3>Accent</h3><div class="swatch-grid accents"></div>' +
      '<p class="set-note">Saved to localStorage \u2014 survives refresh.</p>';

    const walls = body.querySelector('.walls');
    const accents = body.querySelector('.accents');

    for (const w of ZOS.WALLPAPERS) {
      const b = document.createElement('button');
      b.className = 'swatch';
      b.textContent = w.name;
      b.style.background = w.css;
      b.addEventListener('click', () => ZOS.desktop.setWallpaper(w.css));
      walls.appendChild(b);
    }
    for (const a of ZOS.ACCENTS) {
      const b = document.createElement('button');
      b.className = 'swatch swatch-accent';
      b.textContent = a.name;
      b.style.setProperty('--sw', a.c);
      b.addEventListener('click', () => ZOS.desktop.setAccent(a.c));
      accents.appendChild(b);
    }
  }

  ZOS.registerApp({
    id: 'settings',
    name: 'Settings',
    icon: '\u2699',
    desktop: true,
    width: 420,
    height: 350,
    launch(b, w) { app(b, w); },
  });
})();
