/* ============================================================
   Z-OS About — live system panel
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;

  function app(body, win) {
    body.classList.add('about-app');
    body.innerHTML =
      '<div class="about">' +
      '<div class="about-logo">Z</div>' +
      '<h2>Z-OS <span class="ver">v0.1.0 \u2014 first boot</span></h2>' +
      '<p>A tiny desktop that lives in your browser: window manager, terminal, files. No build step, no dependencies.</p>' +
      '<p class="about-stat">Frame rate: <b class="ab-fps">--</b> fps \u00b7 target <b>60</b></p>' +
      '<p class="about-stat">Windows open: <b class="ab-win">0</b></p>' +
      '<p class="about-dim">rAF-batched input \u00b7 compositor transforms \u00b7 localStorage VFS</p>' +
      '</div>';

    const fpsEl = body.querySelector('.ab-fps');
    const winEl = body.querySelector('.ab-win');
    const iv = setInterval(() => {
      if (ZOS.fps) fpsEl.textContent = String(Math.round(ZOS.fps.current()));
      winEl.textContent = String(ZOS.wm.windows.length);
    }, 500);
    win.onClose = () => clearInterval(iv);
  }

  ZOS.registerApp({
    id: 'about',
    name: 'About Z-OS',
    icon: '\u25C9',
    width: 400,
    height: 330,
    launch(b, w) { app(b, w); },
  });
})();
