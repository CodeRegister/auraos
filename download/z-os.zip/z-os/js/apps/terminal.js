/* ============================================================
   Z-OS Terminal — simulated shell over the virtual filesystem
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;

  const LOGO = [
    '████████',
    '     ██ ',
    '    ██  ',
    '   ██   ',
    '  ██    ',
    '████████',
  ];

  function app(body, win) {
    body.classList.add('terminal-app');
    body.innerHTML =
      '<div class="term-scroll"><div class="term-out"></div></div>' +
      '<div class="term-line">' +
      '<span class="term-prompt"></span>' +
      '<input class="term-input" spellcheck="false" autocomplete="off" aria-label="terminal input">' +
      '</div>';
    const out = body.querySelector('.term-out');
    const scroll = body.querySelector('.term-scroll');
    const input = body.querySelector('.term-input');
    const promptEl = body.querySelector('.term-prompt');

    const state = { cwd: ZOS.fs.HOME, history: [], hIdx: 0, t0: ZOS.bootTime || Date.now() };

    function pretty(p) {
      if (p === ZOS.fs.HOME) return '~';
      if (p.indexOf(ZOS.fs.HOME) === 0) return '~' + p.slice(ZOS.fs.HOME.length);
      return p;
    }
    function promptText() { return 'guest@z-os:' + pretty(state.cwd) + '$'; }
    function setPrompt() { promptEl.textContent = promptText(); }

    function print(text, cls) {
      const div = document.createElement('div');
      div.className = 'term-row' + (cls ? ' ' + cls : '');
      div.textContent = text === undefined ? '' : String(text);
      out.appendChild(div);
      scroll.scrollTop = scroll.scrollHeight;
    }
    function printRow(nodes) {
      const div = document.createElement('div');
      div.className = 'term-row';
      for (const n of nodes) {
        const s = document.createElement('span');
        s.textContent = n.text;
        if (n.cls) s.className = n.cls;
        div.appendChild(s);
      }
      out.appendChild(div);
      scroll.scrollTop = scroll.scrollHeight;
    }

    const commands = {
      help() {
        print('Z-OS shell - available commands:');
        [
          'help              this message',
          'neofetch          system info',
          'ls [path]         list directory',
          'cd <path>         change directory (~ works)',
          'pwd               print working directory',
          'cat <file>        print file',
          'echo <text>       print text',
          'mkdir <dir>       create directory',
          'touch <file>      create empty file',
          'rm [-r] <path>    remove file or directory',
          'mv <from> <to>    move / rename',
          'open <path|app>   open in Editor/Files, or launch app',
          'ps                list open windows',
          'fps               live frame rate',
          'date | whoami | clear | reboot',
        ].forEach((l) => print('  ' + l));
      },
      clear() { out.textContent = ''; },
      whoami() { print('guest'); },
      date() { print(new Date().toString()); },
      pwd() { print(state.cwd); },
      echo(args) { print(args.join(' ')); },
      reboot() {
        print('rebooting...');
        setTimeout(() => location.reload(), 400);
      },
      fps() {
        const v = ZOS.fps ? ZOS.fps.current() : null;
        print(v ? 'frame rate: ' + v.toFixed(0) + ' fps (target 60)' : 'fps meter not ready');
      },
      ls(args) {
        const p = ZOS.fs.resolve(state.cwd, args[0] || '.');
        let names;
        try { names = ZOS.fs.ls(p); }
        catch (err) { print('ls: ' + err.message); return; }
        if (!names.length) return;
        printRow(names.map((name) => {
          const full = ZOS.fs.resolve(p, name);
          const isDir = ZOS.fs.isDir(full);
          return { text: isDir ? name + '/' : name, cls: isDir ? 't-dir' : '' };
        }));
      },
      cd(args) {
        const target = args[0] ? ZOS.fs.resolve(state.cwd, args[0]) : ZOS.fs.HOME;
        if (!ZOS.fs.isDir(target)) { print('cd: not a directory: ' + (args[0] || '')); return; }
        state.cwd = target;
        setPrompt();
      },
      cat(args) {
        if (!args[0]) { print('usage: cat <file>'); return; }
        const p = ZOS.fs.resolve(state.cwd, args[0]);
        try { print(ZOS.fs.readFile(p).replace(/\n$/, '')); }
        catch (err) { print('cat: ' + err.message); }
      },
      mkdir(args) {
        if (!args[0]) { print('usage: mkdir <dir>'); return; }
        try { ZOS.fs.mkdir(ZOS.fs.resolve(state.cwd, args[0])); }
        catch (err) { print('mkdir: ' + err.message); }
      },
      touch(args) {
        if (!args[0]) { print('usage: touch <file>'); return; }
        const p = ZOS.fs.resolve(state.cwd, args[0]);
        try { if (!ZOS.fs.exists(p)) ZOS.fs.writeFile(p, ''); }
        catch (err) { print('touch: ' + err.message); }
      },
      rm(args) {
        const rec = args[0] === '-r';
        const target = rec ? args[1] : args[0];
        if (!target) { print('usage: rm [-r] <path>'); return; }
        try { ZOS.fs.rm(ZOS.fs.resolve(state.cwd, target), rec); }
        catch (err) { print('rm: ' + err.message); }
      },
      mv(args) {
        if (args.length < 2) { print('usage: mv <from> <to>'); return; }
        try { ZOS.fs.mv(ZOS.fs.resolve(state.cwd, args[0]), ZOS.fs.resolve(state.cwd, args[1])); }
        catch (err) { print('mv: ' + err.message); }
      },
      open(args) {
        if (!args[0]) { print('usage: open <path|app>'); return; }
        const appIds = ['terminal', 'files', 'settings', 'about', 'editor'];
        if (appIds.indexOf(args[0]) >= 0) {
          ZOS.desktop.launch(args[0]);
          print('opening ' + args[0] + '...');
          return;
        }
        const p = ZOS.fs.resolve(state.cwd, args[0]);
        if (ZOS.fs.isDir(p)) { ZOS.desktop.launch('files', { path: p }); print('opening ' + p); return; }
        if (ZOS.fs.exists(p)) { ZOS.desktop.launch('editor', { path: p }); print('opening ' + p); return; }
        print('open: no such file or app: ' + args[0]);
      },
      ps() {
        if (!ZOS.wm.windows.length) { print('(no windows open)'); return; }
        print('PID   APP         TITLE');
        ZOS.wm.windows.forEach((w, i) => {
          print(String(i + 1).padStart(3) + '   ' + String(w.appId || '?').padEnd(11) + ' ' + w.title);
        });
      },
      neofetch() {
        const up = Math.max(0, Math.floor((Date.now() - state.t0) / 1000));
        const info = [
          'guest@z-os',
          '-----------',
          'OS:        Z-OS v0.1.0',
          'Kernel:    requestAnimationFrame @ 60hz',
          'Shell:     zsh-ish (simulated)',
          'WM:        zwm (compositor transforms)',
          'FS:        localStorage VFS (' + ZOS.fs.usage() + ' bytes)',
          'Display:   ' + window.innerWidth + 'x' + window.innerHeight,
          'Uptime:    ' + Math.floor(up / 60) + 'm ' + (up % 60) + 's',
          'Windows:   ' + ZOS.wm.windows.length + ' open',
        ];
        const rows = Math.max(LOGO.length, info.length);
        for (let i = 0; i < rows; i++) {
          print((LOGO[i] || '         ').padEnd(11) + (info[i] || ''));
        }
      },
    };

    function exec(line) {
      const parts = line.trim().split(/\s+/).filter(Boolean);
      if (!parts.length) return;
      const fn = commands[parts[0]];
      if (fn) fn(parts.slice(1));
      else print('zsh: command not found: ' + parts[0] + '   (try: help)');
    }

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const line = input.value;
        print(promptText() + ' ' + line, 'term-cmd');
        if (line.trim()) {
          state.history.push(line);
          state.hIdx = state.history.length;
        }
        exec(line);
        input.value = '';
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (state.hIdx > 0) {
          state.hIdx--;
          input.value = state.history[state.hIdx] || '';
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (state.hIdx < state.history.length) {
          state.hIdx++;
          input.value = state.history[state.hIdx] || '';
        }
      } else if (e.key.toLowerCase() === 'l' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        commands.clear();
      }
    });
    scroll.addEventListener('pointerup', () => {
      if (!window.getSelection().toString()) input.focus();
    });
    win.el.addEventListener('pointerdown', () => setTimeout(() => input.focus(), 0));

    setPrompt();
    print('Z-OS terminal - type "help" to get started.', 't-dim');
    setTimeout(() => input.focus(), 60);
  }

  ZOS.registerApp({
    id: 'terminal',
    name: 'Terminal',
    icon: '▮',
    desktop: true,
    width: 640,
    height: 400,
    launch(b, w) { app(b, w); },
  });
})();
