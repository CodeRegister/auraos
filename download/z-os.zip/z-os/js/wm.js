/* ============================================================
   zwm — Z-OS window manager
   pointer events + pointer capture, all movement batched into
   requestAnimationFrame, windows positioned with compositor
   transforms (translate3d) so dragging never triggers layout.
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;
  const wm = (ZOS.wm = { windows: [], zTop: 20, focused: null });

  const container = () => document.getElementById('windows');

  function applyTransform(win) {
    win.el.style.transform = 'translate3d(' + win.x + 'px,' + win.y + 'px,0)';
  }
  function clampX(x, w) {
    const vw = container().clientWidth;
    return Math.max(80 - w, Math.min(x, vw - 80));
  }
  function clampY(y) {
    const vh = container().clientHeight;
    return Math.max(0, Math.min(y, vh - 36));
  }

  function makeTaskItem(win) {
    const bar = document.getElementById('task-items');
    const el = document.createElement('button');
    el.className = 'task-item';
    el.textContent = win.title;
    el.addEventListener('click', () => {
      if (win.minimized) { restore(win); focus(win); }
      else if (wm.focused === win) minimize(win);
      else focus(win);
    });
    bar.appendChild(el);
    win.taskEl = el;
  }

  function focus(win) {
    if (wm.focused === win && !win.minimized) return;
    wm.focused = win;
    for (const w of wm.windows) {
      w.el.classList.toggle('focused', w === win);
      if (w.taskEl) w.taskEl.classList.toggle('active', w === win && !w.minimized);
    }
    win.el.style.zIndex = ++wm.zTop;
  }
  wm.focus = focus;

  function minimize(win) {
    win.minimized = true;
    win.el.classList.add('minimized');
    if (win.taskEl) win.taskEl.classList.remove('active');
    if (wm.focused === win) wm.focused = null;
  }

  function restore(win) {
    win.minimized = false;
    win.el.classList.remove('minimized');
  }

  function toggleMax(win) {
    const c = container();
    if (!win.maximized) {
      win.prev = { x: win.x, y: win.y, w: win.width, h: win.height };
      win.maximized = true;
      win.x = 8;
      win.y = 8;
      win.width = Math.max(280, c.clientWidth - 16);
      win.height = Math.max(160, c.clientHeight - 16);
      win.el.classList.add('maximized');
    } else {
      win.maximized = false;
      win.x = win.prev.x; win.y = win.prev.y;
      win.width = win.prev.w; win.height = win.prev.h;
      win.el.classList.remove('maximized');
    }
    win.el.style.width = win.width + 'px';
    win.el.style.height = win.height + 'px';
    applyTransform(win);
  }
  wm.toggleMax = toggleMax;

  wm.create = function (opts) {
    const win = {
      id: 'w' + Date.now() + '-' + Math.floor(Math.random() * 1e4),
      appId: opts.appId || null,
      title: opts.title || 'window',
      icon: opts.icon || '▪',
      width: opts.width || 560,
      height: opts.height || 380,
      x: 0, y: 0,
      minimized: false,
      maximized: false,
      onClose: opts.onClose || null,
    };

    const el = document.createElement('section');
    el.className = 'window';
    el.innerHTML =
      '<header class="titlebar">' +
      '<span class="tb-ico"></span>' +
      '<span class="tb-title"></span>' +
      '<span class="tb-btns">' +
      '<button class="tb-min" title="Minimize">&#8211;</button>' +
      '<button class="tb-max" title="Maximize">&#9633;</button>' +
      '<button class="tb-close" title="Close">&#215;</button>' +
      '</span></header>' +
      '<div class="win-body"></div>' +
      '<div class="resize-handle"></div>';
    el.querySelector('.tb-ico').textContent = win.icon;
    el.querySelector('.tb-title').textContent = win.title;
    win.el = el;
    win.body = el.querySelector('.win-body');

    /* initial cascade position */
    const n = wm.windows.length % 7;
    win.x = clampX(110 + n * 34, win.width);
    win.y = clampY(60 + n * 28);
    el.style.width = win.width + 'px';
    el.style.height = win.height + 'px';
    applyTransform(win);

    el.addEventListener('pointerdown', () => focus(win));

    /* ---------- drag (titlebar) ---------- */
    const tb = el.querySelector('.titlebar');
    let drag = null;
    tb.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      if (win.maximized) return;
      drag = {
        px: e.clientX, py: e.clientY,
        sx: win.x, sy: win.y,
        nx: win.x, ny: win.y,
        raf: 0,
      };
      tb.setPointerCapture(e.pointerId);
      el.classList.add('dragging');
      e.preventDefault();
    });
    tb.addEventListener('pointermove', (e) => {
      if (!drag) return;
      drag.nx = drag.sx + (e.clientX - drag.px);
      drag.ny = drag.sy + (e.clientY - drag.py);
      if (!drag.raf) {
        drag.raf = requestAnimationFrame(() => {
          drag.raf = 0;
          win.x = clampX(drag.nx, win.width);
          win.y = clampY(drag.ny);
          applyTransform(win);
        });
      }
    });
    const endDrag = () => {
      if (!drag) return;
      if (drag.raf) cancelAnimationFrame(drag.raf);
      win.x = clampX(drag.nx, win.width);
      win.y = clampY(drag.ny);
      applyTransform(win);
      drag = null;
      el.classList.remove('dragging');
    };
    tb.addEventListener('pointerup', endDrag);
    tb.addEventListener('pointercancel', endDrag);
    tb.addEventListener('dblclick', (e) => {
      if (!e.target.closest('button')) toggleMax(win);
    });

    /* ---------- resize (corner handle) ---------- */
    const rh = el.querySelector('.resize-handle');
    let rs = null;
    rh.addEventListener('pointerdown', (e) => {
      if (win.maximized) return;
      rs = {
        px: e.clientX, py: e.clientY,
        sw: win.width, sh: win.height,
        nw: win.width, nh: win.height,
        raf: 0,
      };
      rh.setPointerCapture(e.pointerId);
      e.preventDefault();
      e.stopPropagation();
    });
    rh.addEventListener('pointermove', (e) => {
      if (!rs) return;
      rs.nw = Math.max(280, rs.sw + (e.clientX - rs.px));
      rs.nh = Math.max(160, rs.sh + (e.clientY - rs.py));
      if (!rs.raf) {
        rs.raf = requestAnimationFrame(() => {
          rs.raf = 0;
          win.width = rs.nw;
          win.height = rs.nh;
          el.style.width = win.width + 'px';
          el.style.height = win.height + 'px';
        });
      }
    });
    const endRs = () => {
      if (!rs) return;
      if (rs.raf) cancelAnimationFrame(rs.raf);
      rs = null;
    };
    rh.addEventListener('pointerup', endRs);
    rh.addEventListener('pointercancel', endRs);

    /* ---------- window controls ---------- */
    el.querySelector('.tb-min').addEventListener('click', () => minimize(win));
    el.querySelector('.tb-max').addEventListener('click', () => toggleMax(win));
    el.querySelector('.tb-close').addEventListener('click', () => wm.close(win));

    /* ---------- mount ---------- */
    container().appendChild(el);
    wm.windows.push(win);
    makeTaskItem(win);
    if (opts.content) opts.content(win.body, win);
    focus(win);
    return win;
  };

  wm.close = function (win) {
    if (win.onClose) {
      try { win.onClose(); }
      catch (err) { console.error('[wm] onClose', err); }
    }
    win.el.remove();
    if (win.taskEl) win.taskEl.remove();
    const i = wm.windows.indexOf(win);
    if (i >= 0) wm.windows.splice(i, 1);
    if (wm.focused === win) {
      wm.focused = null;
      let top = null;
      for (const w of wm.windows) {
        if (!w.minimized && (!top || Number(w.el.style.zIndex) > Number(top.el.style.zIndex))) top = w;
      }
      if (top) focus(top);
    }
  };

  wm.closeAll = function () {
    for (const w of wm.windows.slice()) wm.close(w);
  };
})();
