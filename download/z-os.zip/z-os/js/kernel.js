/* ============================================================
   Z-OS kernel — event bus + virtual filesystem + persistence
   ============================================================ */
(function () {
  'use strict';
  const ZOS = (window.ZOS = window.ZOS || {});

  /* ---------- app registry ---------- */
  ZOS.apps = {};
  ZOS.registerApp = function (app) { ZOS.apps[app.id] = app; };

  /* ---------- event bus ---------- */
  const listeners = new Map(); // evt -> Set<fn>
  ZOS.bus = {
    on(evt, fn) {
      if (!listeners.has(evt)) listeners.set(evt, new Set());
      listeners.get(evt).add(fn);
      return function off() { ZOS.bus.off(evt, fn); };
    },
    off(evt, fn) {
      const s = listeners.get(evt);
      if (s) s.delete(fn);
    },
    emit(evt) {
      const s = listeners.get(evt);
      if (!s) return;
      const args = Array.prototype.slice.call(arguments, 1);
      for (const fn of Array.from(s)) {
        try { fn.apply(null, args); }
        catch (err) { console.error('[bus]', evt, err); }
      }
    },
  };

  /* ---------- virtual filesystem ---------- */
  const STORE_KEY = 'zos.vfs.v1';
  const now = () => new Date().toISOString();

  const mkDir = (name) => ({ type: 'dir', name, mtime: now(), children: {} });
  const mkFile = (name, content) => ({ type: 'file', name, mtime: now(), content: content || '' });

  function seed() {
    const root = mkDir('/');
    root.children.home = mkDir('home');
    root.children.home.children.guest = mkDir('guest');
    const guest = root.children.home.children.guest;

    guest.children['readme.txt'] = mkFile('readme.txt',
      'Welcome to Z-OS\n' +
      '===============\n\n' +
      'You are guest. The whole desktop runs in your browser:\n' +
      'no servers, no build step, no dependencies.\n\n' +
      'Things to try\n' +
      '-------------\n' +
      '  * Open Terminal and run: help\n' +
      '  * Then: neofetch\n' +
      '  * Make a folder: mkdir demo\n' +
      '  * Watch it appear in Files instantly.\n' +
      '  * Open Files, double-click readme.txt to edit it here.\n\n' +
      'Z-OS keeps everything in localStorage, so your files\n' +
      'survive a refresh. Settings changes the wallpaper.\n\n' +
      'Have fun.\n');

    guest.children.Documents = mkDir('Documents');
    guest.children.Documents.children['roadmap.md'] = mkFile('roadmap.md',
      '# Z-OS roadmap\n\n' +
      'The standing daily-commit menu - pick one, ship it, commit.\n\n' +
      '- [ ] Terminal: tab-completion for paths and commands\n' +
      '- [ ] Terminal: pipes (cat x | sort)\n' +
      '- [ ] Terminal: command history search (Ctrl+R)\n' +
      '- [ ] Files: drag files between folders\n' +
      '- [ ] Files: list view + sort by name/size/date\n' +
      '- [ ] WM: snap zones (drag window to screen edges)\n' +
      '- [ ] WM: open/minimize animations\n' +
      '- [ ] Editor: syntax highlighting\n' +
      '- [ ] New app: calculator\n' +
      '- [ ] New app: pomodoro timer\n' +
      '- [ ] New app: pixel art painter\n');

    guest.children.Documents.children['notes.md'] = mkFile('notes.md',
      '# Notes\n\n' +
      '- Z-OS boots in under a second\n' +
      '- The window manager is requestAnimationFrame-driven\n' +
      '- Windows move on compositor transforms (translate3d)\n');

    guest.children.Pictures = mkDir('Pictures');
    guest.children.Pictures.children['wallpapers.txt'] = mkFile('wallpapers.txt',
      'Gradient presets live in js/apps/settings.js - add your own!\n');

    guest.children.Projects = mkDir('Projects');
    guest.children.Projects.children['hello.js'] = mkFile('hello.js',
      '// open me with: open ~/Projects/hello.js\n' +
      'console.log("hello from Z-OS");\n');

    return root;
  }

  let root;
  try {
    const raw = localStorage.getItem(STORE_KEY);
    root = raw ? JSON.parse(raw) : seed();
  } catch (err) {
    console.warn('[fs] storage unavailable, using in-memory fs', err);
    root = seed();
  }

  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(root)); }
    catch (err) { /* storage full or blocked - stay in memory */ }
  }
  let saveTimer = null;
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 120);
  }

  function normalize(path) {
    const abs = path.charAt(0) === '/';
    const out = [];
    for (const part of path.split('/')) {
      if (!part || part === '.') continue;
      if (part === '..') { out.pop(); continue; }
      out.push(part);
    }
    return (abs ? '/' : '') + out.join('/');
  }

  function resolve(cwd, path) {
    if (!path) return normalize(cwd);
    if (path === '~') return '/home/guest';
    if (path.indexOf('~/') === 0) path = '/home/guest/' + path.slice(2);
    return path.charAt(0) === '/' ? normalize(path) : normalize(cwd + '/' + path);
  }

  function nodeAt(path) {
    if (path === '/' || path === '') return root;
    let node = root;
    for (const part of path.split('/').filter(Boolean)) {
      if (!node || node.type !== 'dir' || !node.children[part]) return null;
      node = node.children[part];
    }
    return node;
  }

  function parentOf(path) {
    const idx = path.lastIndexOf('/');
    return idx <= 0 ? '/' : path.slice(0, idx);
  }
  function baseName(path) {
    return path === '/' ? '/' : path.slice(path.lastIndexOf('/') + 1);
  }

  const fs = {
    HOME: '/home/guest',
    normalize, resolve, parentOf, baseName,
    exists(p) { return !!nodeAt(p); },
    isDir(p) { const n = nodeAt(p); return !!n && n.type === 'dir'; },
    get: nodeAt,
    ls(p) {
      const n = nodeAt(p);
      if (!n) throw new Error('no such file or directory: ' + p);
      if (n.type === 'file') return [n.name];
      return Object.keys(n.children).sort((a, b) => {
        const da = n.children[a].type === 'dir';
        const db = n.children[b].type === 'dir';
        return da === db ? a.localeCompare(b) : (da ? -1 : 1);
      });
    },
    mkdir(p) {
      const parent = nodeAt(parentOf(p));
      if (!parent || parent.type !== 'dir') throw new Error('no such directory: ' + parentOf(p));
      const name = baseName(p);
      if (!name) throw new Error('invalid name');
      if (parent.children[name]) throw new Error('already exists: ' + p);
      parent.children[name] = mkDir(name);
      saveSoon();
      ZOS.bus.emit('fs:changed', p);
    },
    writeFile(p, content) {
      const parent = nodeAt(parentOf(p));
      if (!parent || parent.type !== 'dir') throw new Error('no such directory: ' + parentOf(p));
      const name = baseName(p);
      if (!name) throw new Error('invalid name');
      const existing = parent.children[name];
      if (existing && existing.type === 'dir') throw new Error('is a directory: ' + p);
      if (existing) { existing.content = content; existing.mtime = now(); }
      else parent.children[name] = mkFile(name, content);
      saveSoon();
      ZOS.bus.emit('fs:changed', p);
    },
    readFile(p) {
      const n = nodeAt(p);
      if (!n) throw new Error('no such file: ' + p);
      if (n.type === 'dir') throw new Error('is a directory: ' + p);
      return n.content;
    },
    rm(p, recursive) {
      if (p === '/') throw new Error('refusing to remove root');
      const n = nodeAt(p);
      if (!n) throw new Error('no such file or directory: ' + p);
      if (n.type === 'dir' && Object.keys(n.children).length && !recursive) {
        throw new Error('directory not empty (use rm -r): ' + p);
      }
      const parent = nodeAt(parentOf(p));
      delete parent.children[baseName(p)];
      saveSoon();
      ZOS.bus.emit('fs:changed', p);
    },
    mv(from, to) {
      const node = nodeAt(from);
      if (!node) throw new Error('no such file or directory: ' + from);
      let dstParent, name;
      const destNode = nodeAt(to);
      if (destNode && destNode.type === 'dir') { dstParent = destNode; name = baseName(from); }
      else { dstParent = nodeAt(parentOf(to)); name = baseName(to); }
      if (!dstParent || dstParent.type !== 'dir') throw new Error('no such directory: ' + (dstParent ? to : parentOf(to)));
      if (dstParent.children[name]) throw new Error('already exists: ' + name);
      delete nodeAt(parentOf(from)).children[baseName(from)];
      node.name = name;
      dstParent.children[name] = node;
      saveSoon();
      ZOS.bus.emit('fs:changed', from);
      ZOS.bus.emit('fs:changed', to);
    },
    usage() { return (JSON.stringify(root) || '').length; },
  };

  ZOS.fs = fs;
})();
