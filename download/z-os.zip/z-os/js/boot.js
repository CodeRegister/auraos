/* ============================================================
   Z-OS boot — overlay, desktop, start menu, clock, fps meter
   ============================================================ */
(function () {
  'use strict';
  const ZOS = window.ZOS;
  ZOS.bootTime = Date.now();

  /* ---------- global fps meter (one cheap rAF loop) ---------- */
  const fps = (ZOS.fps = {
    frames: 0,
    last: performance.now(),
    value: 60,
    current() { return this.value; },
  });
  function fpsLoop(t) {
    fps.frames++;
    if (t - fps.last >= 500) {
      fps.value = (fps.frames * 1000) / (t - fps.last);
      fps.frames = 0;
      fps.last = t;
      const el = document.getElementById('fps-meter');
      if (el) el.textContent = Math.round(fps.value) + ' fps';
    }
    requestAnimationFrame(fpsLoop);
  }
  requestAnimationFrame(fpsLoop);

  /* ---------- clock ---------- */
  function tickClock() {
    const el = document.getElementById('clock');
    if (el) el.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  /* ---------- desktop controller ---------- */
  ZOS.desktop = {
    launch(appId, opts) {
      const app = ZOS.apps[appId];
      if (!app) return null;
      return ZOS.wm.create({
        title: app.name,
        icon: app.icon,
        width: app.width,
        height: app.height,
        appId: app.id,
        content(body, win) { app.launch(body, win, opts || {}); },
      });
    },
    setWallpaper(css) {
      document.getElementById('desktop').style.background = css;
      try { localStorage.setItem('zos.wallpaper', css); } catch (err) { /* ignore */ }
    },
    setAccent(c) {
      document.documentElement.style.setProperty('--accent', c);
      try { localStorage.setItem('zos.accent', c); } catch (err) { /* ignore */ }
    },
  };

  /* ---------- start menu ---------- */
  function buildStartMenu() {
    const menu = document.getElementById('start-menu');
    menu.textContent = '';
    const head = document.createElement('div');
    head.className = 'sm-head';
    head.textContent = 'Z-OS \u2014 applications';
    menu.appendChild(head);
    for (const id of Object.keys(ZOS.apps)) {
      const app = ZOS.apps[id];
      const b = document.createElement('button');
      b.className = 'sm-item';
      const ico = document.createElement('span');
      ico.className = 'sm-ico';
      ico.textContent = app.icon;
      const lab = document.createElement('span');
      lab.textContent = app.name;
      b.appendChild(ico);
      b.appendChild(lab);
      b.addEventListener('click', () => {
        ZOS.desktop.launch(app.id);
        menu.classList.add('hidden');
      });
      menu.appendChild(b);
    }
    const foot = document.createElement('div');
    foot.className = 'sm-foot';
    foot.textContent = 'v0.1.0 \u00b7 60fps or bust';
    menu.appendChild(foot);
  }

  /* ---------- desktop icons ---------- */
  function buildIcons() {
    const icons = document.getElementById('icons');
    icons.textContent = '';
    const add = (label, ico, fn) => {
      const d = document.createElement('button');
      d.className = 'desk-icon';
      const i = document.createElement('span');
      i.className = 'di-ico';
      i.textContent = ico;
      const l = document.createElement('span');
      l.className = 'di-label';
      l.textContent = label;
      d.appendChild(i);
      d.appendChild(l);
      d.addEventListener('dblclick', fn);
      icons.appendChild(d);
    };
    add('Terminal', '\u25AE', () => ZOS.desktop.launch('terminal'));
    add('Files', '\uD83D\uDDC1', () => ZOS.desktop.launch('files'));
    add('readme.txt', '\u270E', () => ZOS.desktop.launch('editor', { path: ZOS.fs.HOME + '/readme.txt' }));
    add('Settings', '\u2699', () => ZOS.desktop.launch('settings'));
  }

  /* ---------- boot overlay ---------- */
  function runBoot() {
    const overlay = document.getElementById('boot');
    const bar = overlay.querySelector('.boot-bar-fill');
    const log = overlay.querySelector('.boot-log');
    const lines = [
      '[ ok ] z-kernel: vfs mounted (localStorage)',
      '[ ok ] zwm: compositor online (rAF @ 60hz)',
      '[ ok ] shell: zsh-ish registered',
      '[ ok ] reaching desktop...',
    ];
    let i = 0;
    bar.style.width = '8%';
    const step = () => {
      if (i < lines.length) {
        const d = document.createElement('div');
        d.textContent = lines[i];
        log.appendChild(d);
        bar.style.width = 10 + (i + 1) * 22 + '%';
        i++;
        setTimeout(step, 170);
      } else {
        setTimeout(() => {
          overlay.classList.add('done');
          setTimeout(() => overlay.remove(), 460);
          let seen = null;
          try { seen = localStorage.getItem('zos.seen'); } catch (err) { /* ignore */ }
          if (!seen) {
            try { localStorage.setItem('zos.seen', '1'); } catch (err) { /* ignore */ }
            ZOS.desktop.launch('about');
          }
        }, 240);
      }
    };
    setTimeout(step, 240);
  }

  /* ---------- saved preferences ---------- */
  function applyPrefs() {
    try {
      const w = localStorage.getItem('zos.wallpaper');
      if (w) ZOS.desktop.setWallpaper(w);
      const a = localStorage.getItem('zos.accent');
      if (a) ZOS.desktop.setAccent(a);
    } catch (err) { /* ignore */ }
  }

  /* ---------- init ---------- */
  window.addEventListener('DOMContentLoaded', () => {
    buildStartMenu();
    buildIcons();
    applyPrefs();
    tickClock();
    setInterval(tickClock, 1000);

    const startBtn = document.getElementById('start-btn');
    const menu = document.getElementById('start-menu');
    startBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      menu.classList.toggle('hidden');
    });
    document.addEventListener('pointerdown', (e) => {
      if (!menu.classList.contains('hidden') &&
          !e.target.closest('#start-menu') &&
          !e.target.closest('#start-btn')) {
        menu.classList.add('hidden');
      }
    });

    runBoot();
  });
})();
